import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Trophy, Zap, Target, TrendingUp, Award, Star } from 'lucide-react';
import { YearLevel, AnswerFormat } from '@shared/schema';

interface XPDashboardProps {
  totalXP: number;
  currentLevel: number;
  questionsAnswered: number;
  correctAnswers: number;
  currentYear: YearLevel;
  currentFormat: AnswerFormat;
  onBoostActivate: () => void;
  isBoostActive: boolean;
  boostTimeLeft: number; // in seconds
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  unlocked: boolean;
  progress?: number;
  maxProgress?: number;
}

const LEVEL_XP_REQUIREMENTS = [0, 100, 250, 450, 700, 1000, 1350, 1750, 2200, 2700, 3250];
const XP_MULTIPLIERS = { mcq: 1, text: 2, mixed: 3 };

export default function XPDashboard({
  totalXP,
  currentLevel,
  questionsAnswered,
  correctAnswers,
  currentYear,
  currentFormat,
  onBoostActivate,
  isBoostActive,
  boostTimeLeft,
}: XPDashboardProps) {
  const [showAchievements, setShowAchievements] = useState(false);
  const [recentXPGain, setRecentXPGain] = useState(0);
  const [showXPAnimation, setShowXPAnimation] = useState(false);

  // Calculate XP for next level
  const currentLevelXP = LEVEL_XP_REQUIREMENTS[currentLevel - 1] || 0;
  const nextLevelXP = LEVEL_XP_REQUIREMENTS[currentLevel] || currentLevelXP + 500;
  const xpInCurrentLevel = totalXP - currentLevelXP;
  const xpNeededForNextLevel = nextLevelXP - currentLevelXP;
  const progressPercentage = Math.min((xpInCurrentLevel / xpNeededForNextLevel) * 100, 100);

  // Calculate accuracy
  const accuracy = questionsAnswered > 0 ? Math.round((correctAnswers / questionsAnswered) * 100) : 0;

  // Calculate current XP multiplier
  const currentXPMultiplier = currentYear * XP_MULTIPLIERS[currentFormat];

  // Mock achievements - todo: replace with real achievement system
  const achievements: Achievement[] = [
    {
      id: 'first-correct',
      title: 'First Steps',
      description: 'Answer your first question correctly',
      icon: Target,
      unlocked: correctAnswers >= 1,
    },
    {
      id: 'streak-5',
      title: 'On Fire',
      description: 'Answer 5 questions in a row correctly',
      icon: Trophy,
      unlocked: correctAnswers >= 5,
      progress: Math.min(correctAnswers, 5),
      maxProgress: 5,
    },
    {
      id: 'level-up',
      title: 'Level Master',
      description: 'Reach level 5',
      icon: Award,
      unlocked: currentLevel >= 5,
      progress: currentLevel,
      maxProgress: 5,
    },
    {
      id: 'xp-collector',
      title: 'XP Collector',
      description: 'Earn 1000 total XP',
      icon: Star,
      unlocked: totalXP >= 1000,
      progress: Math.min(totalXP, 1000),
      maxProgress: 1000,
    },
  ];

  // Format boost time remaining
  const formatBoostTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Simulate XP gain animation (for demo purposes)
  const simulateXPGain = () => {
    const xpGain = currentXPMultiplier;
    setRecentXPGain(xpGain);
    setShowXPAnimation(true);
    setTimeout(() => setShowXPAnimation(false), 2000);
    console.log(`+${xpGain} XP earned!`);
  };

  return (
    <div className="space-y-6">
      {/* Main XP Progress */}
      <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <Trophy className="h-5 w-5 text-primary" />
              XP Dashboard
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="font-bold">
                Level {currentLevel}
              </Badge>
              {showXPAnimation && (
                <Badge variant="default" className="animate-bounce">
                  +{recentXPGain} XP
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* XP Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                {xpInCurrentLevel} / {xpNeededForNextLevel} XP
              </span>
              <span className="font-medium">
                {nextLevelXP - totalXP} XP to level {currentLevel + 1}
              </span>
            </div>
            <Progress 
              value={progressPercentage} 
              className="h-3"
              data-testid="xp-progress-bar"
            />
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{totalXP}</div>
              <div className="text-xs text-muted-foreground">Total XP</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{accuracy}%</div>
              <div className="text-xs text-muted-foreground">Accuracy</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{questionsAnswered}</div>
              <div className="text-xs text-muted-foreground">Questions</div>
            </div>
          </div>

          {/* Current Multiplier */}
          <div className="bg-accent/30 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Current XP Rate</div>
                <div className="text-sm text-muted-foreground">
                  Year {currentYear} × {currentFormat} format
                </div>
              </div>
              <Badge variant="default" className="text-lg font-bold">
                {currentXPMultiplier} XP
              </Badge>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button
              onClick={onBoostActivate}
              disabled={isBoostActive}
              variant={isBoostActive ? "secondary" : "default"}
              className="flex-1"
              data-testid="button-boost"
            >
              <Zap className="h-4 w-4 mr-2" />
              {isBoostActive ? `Boost Active (${formatBoostTime(boostTimeLeft)})` : 'Activate 2x Boost'}
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowAchievements(!showAchievements)}
              data-testid="button-achievements"
            >
              <Award className="h-4 w-4" />
            </Button>
          </div>

          {/* Demo XP Gain Button (todo: remove when implementing real questions) */}
          <Button
            variant="outline"
            onClick={simulateXPGain}
            className="w-full"
            data-testid="button-demo-xp"
          >
            <TrendingUp className="h-4 w-4 mr-2" />
            Demo: Earn XP ({currentXPMultiplier} XP)
          </Button>
        </CardContent>
      </Card>

      {/* Achievements Panel */}
      {showAchievements && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {achievements.map((achievement) => {
                const Icon = achievement.icon;
                return (
                  <div
                    key={achievement.id}
                    className={`flex items-center gap-3 p-3 rounded-lg border ${
                      achievement.unlocked 
                        ? 'bg-primary/5 border-primary/20' 
                        : 'bg-muted/30 border-muted'
                    }`}
                    data-testid={`achievement-${achievement.id}`}
                  >
                    <Icon 
                      className={`h-8 w-8 ${
                        achievement.unlocked ? 'text-primary' : 'text-muted-foreground'
                      }`} 
                    />
                    <div className="flex-1">
                      <div className={`font-medium ${
                        achievement.unlocked ? 'text-foreground' : 'text-muted-foreground'
                      }`}>
                        {achievement.title}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {achievement.description}
                      </div>
                      {achievement.progress !== undefined && achievement.maxProgress && (
                        <Progress 
                          value={(achievement.progress / achievement.maxProgress) * 100} 
                          className="mt-2 h-1"
                        />
                      )}
                    </div>
                    {achievement.unlocked && (
                      <Badge variant="default">Unlocked</Badge>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}