import { useState } from 'react';
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem 
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Calculator, FlaskConical, Globe, Trophy, Target } from 'lucide-react';
import { YearLevel, Subject, AnswerFormat } from '@shared/schema';

interface AppSidebarProps {
  currentYear: YearLevel;
  currentSubject: Subject;
  currentTopic: string;
  currentFormat: AnswerFormat;
  onYearChange: (year: YearLevel) => void;
  onSubjectChange: (subject: Subject) => void;
  onTopicChange: (topic: string) => void;
  onFormatChange: (format: AnswerFormat) => void;
}

const SUBJECTS = [
  { id: 'math' as Subject, name: 'Mathematics', icon: Calculator, color: 'bg-blue-100 text-blue-700' },
  { id: 'science' as Subject, name: 'Science', icon: FlaskConical, color: 'bg-green-100 text-green-700' },
  { id: 'english' as Subject, name: 'English', icon: BookOpen, color: 'bg-purple-100 text-purple-700' },
  { id: 'history' as Subject, name: 'History', icon: Globe, color: 'bg-orange-100 text-orange-700' },
];

const TOPICS_BY_SUBJECT: Record<Subject, Record<YearLevel, string[]>> = {
  math: {
    1: ['Counting', 'Addition', 'Subtraction', 'Shapes'],
    2: ['Multiplication', 'Division', 'Fractions', 'Time'],
    3: ['Decimals', 'Measurement', 'Geometry', 'Data'],
    4: ['Long Division', 'Area & Perimeter', 'Angles', 'Statistics'],
    5: ['Fractions & Decimals', 'Volume', 'Coordinates', 'Probability'],
    6: ['Percentages', 'Ratio', 'Algebra Basics', 'Graphs'],
    7: ['Linear Equations', 'Geometry', 'Statistics', 'Probability'],
    8: ['Quadratic Equations', 'Trigonometry', 'Functions', 'Data Analysis'],
    9: ['Advanced Algebra', 'Circle Geometry', 'Calculus Intro', 'Modeling'],
    10: ['Functions', 'Trigonometry', 'Statistics', 'Calculus'],
    11: ['Advanced Functions', 'Calculus', 'Statistics', 'Vectors'],
    12: ['Calculus', 'Complex Numbers', 'Statistics', 'Mechanics'],
  },
  science: {
    1: ['Living Things', 'Materials', 'Forces', 'Earth & Space'],
    2: ['Animals', 'Plants', 'Weather', 'Light & Sound'],
    3: ['Body Systems', 'Rocks & Soil', 'Energy', 'Ecosystems'],
    4: ['Classification', 'States of Matter', 'Electricity', 'Solar System'],
    5: ['Cells', 'Chemical Changes', 'Forces & Motion', 'Environment'],
    6: ['Genetics', 'Acids & Bases', 'Waves', 'Earth Systems'],
    7: ['Biology Basics', 'Chemistry Intro', 'Physics Basics', 'Earth Science'],
    8: ['Cell Biology', 'Atomic Structure', 'Motion & Forces', 'Climate'],
    9: ['Evolution', 'Chemical Bonding', 'Energy & Waves', 'Geology'],
    10: ['Ecology', 'Organic Chemistry', 'Electricity & Magnetism', 'Astronomy'],
    11: ['Molecular Biology', 'Thermochemistry', 'Quantum Physics', 'Environmental Science'],
    12: ['Biochemistry', 'Advanced Chemistry', 'Modern Physics', 'Earth Systems'],
  },
  english: {
    1: ['Phonics', 'Reading', 'Writing', 'Speaking'],
    2: ['Vocabulary', 'Comprehension', 'Grammar Basics', 'Stories'],
    3: ['Spelling', 'Reading Skills', 'Writing Skills', 'Poetry'],
    4: ['Advanced Reading', 'Grammar', 'Creative Writing', 'Drama'],
    5: ['Literature', 'Essay Writing', 'Language Skills', 'Media'],
    6: ['Novel Study', 'Persuasive Writing', 'Speaking & Listening', 'Film'],
    7: ['Text Analysis', 'Narrative Writing', 'Grammar & Style', 'Media Literacy'],
    8: ['Poetry Analysis', 'Argumentative Writing', 'Language Conventions', 'Drama Study'],
    9: ['Classic Literature', 'Expository Writing', 'Advanced Grammar', 'Multimedia'],
    10: ['Modern Literature', 'Research Writing', 'Critical Analysis', 'Public Speaking'],
    11: ['World Literature', 'Advanced Composition', 'Rhetoric', 'Independent Study'],
    12: ['Contemporary Issues', 'College Writing', 'Critical Theory', 'Portfolio'],
  },
  history: {
    1: ['Family History', 'Community', 'Past & Present', 'Celebrations'],
    2: ['Local History', 'Famous People', 'Changes Over Time', 'Cultures'],
    3: ['Ancient Civilizations', 'Exploration', 'Indigenous Peoples', 'Traditions'],
    4: ['World Civilizations', 'Colonization', 'Cultural Exchange', 'Timelines'],
    5: ['Medieval Times', 'Renaissance', 'Age of Discovery', 'Revolutions'],
    6: ['Industrial Revolution', 'World Wars', 'Modern Nations', 'Globalization'],
    7: ['Ancient History', 'Medieval Period', 'Early Modern', 'Enlightenment'],
    8: ['Industrial Age', '19th Century', 'Imperialism', 'Social Movements'],
    9: ['World War I', 'Interwar Period', 'World War II', 'Cold War Beginnings'],
    10: ['Cold War', 'Decolonization', 'Modern Conflicts', 'Globalization'],
    11: ['Contemporary History', 'Political Systems', 'Economic History', 'Social History'],
    12: ['Historical Analysis', 'Historiography', 'Research Methods', 'Capstone Project'],
  },
};

const ANSWER_FORMATS: { id: AnswerFormat; name: string; multiplier: number; description: string }[] = [
  { id: 'mcq', name: 'Multiple Choice', multiplier: 1, description: 'Quick selection from options' },
  { id: 'text', name: 'Text Input', multiplier: 2, description: 'Type your own answer' },
  { id: 'mixed', name: 'Mixed Format', multiplier: 3, description: 'Combination of both types' },
];

export default function AppSidebar({
  currentYear,
  currentSubject,
  currentTopic,
  currentFormat,
  onYearChange,
  onSubjectChange,
  onTopicChange,
  onFormatChange,
}: AppSidebarProps) {
  const [expandedSubject, setExpandedSubject] = useState<Subject | null>(currentSubject);

  const yearLevels = Array.from({ length: 12 }, (_, i) => i + 1) as YearLevel[];
  const currentTopics = TOPICS_BY_SUBJECT[currentSubject][currentYear] || [];

  return (
    <Sidebar>
      <SidebarContent className="gap-6">
        {/* Year Level Selection */}
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Year Level
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <div className="grid grid-cols-4 gap-2">
              {yearLevels.map((year) => (
                <Button
                  key={year}
                  variant={year === currentYear ? "default" : "outline"}
                  size="sm"
                  onClick={() => onYearChange(year)}
                  className="h-10 text-sm font-medium"
                  data-testid={`button-year-${year}`}
                >
                  {year}
                </Button>
              ))}
            </div>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Subject Selection */}
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Subjects
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {SUBJECTS.map((subject) => {
                const Icon = subject.icon;
                const isActive = subject.id === currentSubject;
                const isExpanded = expandedSubject === subject.id;
                
                return (
                  <SidebarMenuItem key={subject.id}>
                    <SidebarMenuButton 
                      onClick={() => {
                        onSubjectChange(subject.id);
                        setExpandedSubject(isExpanded ? null : subject.id);
                      }}
                      className={`${isActive ? 'bg-sidebar-accent' : ''} justify-between`}
                      data-testid={`button-subject-${subject.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="h-4 w-4" />
                        <span>{subject.name}</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        Y{currentYear}
                      </Badge>
                    </SidebarMenuButton>
                    
                    {isExpanded && (
                      <div className="mt-2 ml-4 space-y-1">
                        {currentTopics.map((topic) => (
                          <Button
                            key={topic}
                            variant={topic === currentTopic ? "secondary" : "ghost"}
                            size="sm"
                            onClick={() => onTopicChange(topic)}
                            className="w-full justify-start text-sm"
                            data-testid={`button-topic-${topic.toLowerCase().replace(/\s+/g, '-')}`}
                          >
                            {topic}
                          </Button>
                        ))}
                      </div>
                    )}
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Answer Format Selection */}
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center gap-2">
            <Trophy className="h-4 w-4" />
            Answer Format
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <div className="space-y-2">
              {ANSWER_FORMATS.map((format) => (
                <Button
                  key={format.id}
                  variant={format.id === currentFormat ? "default" : "outline"}
                  size="sm"
                  onClick={() => onFormatChange(format.id)}
                  className="w-full justify-between"
                  data-testid={`button-format-${format.id}`}
                >
                  <div className="text-left">
                    <div className="font-medium">{format.name}</div>
                    <div className="text-xs opacity-70">{format.description}</div>
                  </div>
                  <Badge variant="secondary" className="ml-2">
                    {currentYear * format.multiplier}XP
                  </Badge>
                </Button>
              ))}
            </div>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}