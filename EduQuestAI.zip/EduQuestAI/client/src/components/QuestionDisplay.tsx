import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, RotateCcw, ArrowDown } from 'lucide-react';
import { YearLevel, Subject, AnswerFormat, Question } from '@shared/schema';

interface QuestionDisplayProps {
  questions: Question[];
  currentYear: YearLevel;
  currentSubject: Subject;
  currentTopic: string;
  currentFormat: AnswerFormat;
  onAnswerSubmit: (questionId: string, answer: string, isCorrect: boolean, xpEarned: number) => void;
  onLoadMore: () => void;
  loading: boolean;
}

interface QuestionState {
  id: string;
  userAnswer: string;
  selectedOption?: string;
  isSubmitted: boolean;
  isCorrect?: boolean;
  showExplanation: boolean;
}

const XP_MULTIPLIERS = { mcq: 1, text: 2, mixed: 3 };

// Mock question generator for demo (todo: replace with real API)
const generateMockQuestion = (
  id: string,
  yearLevel: YearLevel,
  subject: Subject,
  topic: string,
  format: AnswerFormat
): Question => {
  const mathQuestions = {
    'Linear Equations': [
      { q: 'Solve for x: 2x + 5 = 13', a: '4', explanation: 'Subtract 5 from both sides: 2x = 8. Divide by 2: x = 4' },
      { q: 'If 3x - 7 = 14, what is x?', a: '7', explanation: 'Add 7 to both sides: 3x = 21. Divide by 3: x = 7' },
      { q: 'Solve: 5x + 2 = 3x + 10', a: '4', explanation: 'Subtract 3x from both sides: 2x + 2 = 10. Subtract 2: 2x = 8. Divide by 2: x = 4' },
    ],
    'Geometry': [
      { q: 'What is the area of a rectangle with length 8cm and width 6cm?', a: '48', explanation: 'Area = length × width = 8 × 6 = 48 cm²' },
      { q: 'Find the perimeter of a square with side length 7cm', a: '28', explanation: 'Perimeter = 4 × side length = 4 × 7 = 28 cm' },
    ]
  };

  const questionData = mathQuestions[topic as keyof typeof mathQuestions] || mathQuestions['Linear Equations'];
  const randomQ = questionData[Math.floor(Math.random() * questionData.length)];
  
  const options = format === 'mcq' || (format === 'mixed' && Math.random() > 0.5) ? [
    randomQ.a,
    String(parseInt(randomQ.a) + 1),
    String(parseInt(randomQ.a) - 1),
    String(parseInt(randomQ.a) + 2),
  ].sort(() => Math.random() - 0.5) : undefined;

  return {
    id,
    yearLevel,
    subject,
    topic,
    question: randomQ.q,
    answer: randomQ.a,
    options,
    questionType: options ? 'mcq' : 'text',
    explanation: randomQ.explanation,
    difficulty: 1,
  };
};

export default function QuestionDisplay({
  questions: propQuestions,
  currentYear,
  currentSubject,
  currentTopic,
  currentFormat,
  onAnswerSubmit,
  onLoadMore,
  loading,
}: QuestionDisplayProps) {
  const [questionStates, setQuestionStates] = useState<Map<string, QuestionState>>(new Map());
  const [questions, setQuestions] = useState<Question[]>([]);

  // Generate initial mock questions for demo (todo: replace with real data)
  useEffect(() => {
    const mockQuestions = Array.from({ length: 8 }, (_, i) => 
      generateMockQuestion(
        `q-${currentYear}-${currentSubject}-${currentTopic}-${i}`,
        currentYear,
        currentSubject,
        currentTopic,
        currentFormat
      )
    );
    setQuestions(mockQuestions);
    setQuestionStates(new Map());
  }, [currentYear, currentSubject, currentTopic, currentFormat]);

  const getQuestionState = (questionId: string): QuestionState => {
    return questionStates.get(questionId) || {
      id: questionId,
      userAnswer: '',
      isSubmitted: false,
      showExplanation: false,
    };
  };

  const updateQuestionState = (questionId: string, updates: Partial<QuestionState>) => {
    setQuestionStates(prev => {
      const newStates = new Map(prev);
      const currentState = getQuestionState(questionId);
      newStates.set(questionId, { ...currentState, ...updates });
      return newStates;
    });
  };

  const handleAnswerChange = (questionId: string, answer: string, isOption: boolean = false) => {
    updateQuestionState(questionId, {
      userAnswer: isOption ? '' : answer,
      selectedOption: isOption ? answer : undefined,
    });
  };

  const handleSubmit = (question: Question) => {
    const state = getQuestionState(question.id);
    const userAnswer = state.selectedOption || state.userAnswer.trim();
    
    if (!userAnswer) return;

    const isCorrect = userAnswer.toLowerCase() === question.answer.toLowerCase();
    const xpMultiplier = XP_MULTIPLIERS[currentFormat];
    const xpEarned = currentYear * xpMultiplier * (isCorrect ? 1 : 0);

    updateQuestionState(question.id, {
      isSubmitted: true,
      isCorrect,
      showExplanation: true,
    });

    onAnswerSubmit(question.id, userAnswer, isCorrect, xpEarned);

    // Log for demo purposes
    console.log(`Question answered: ${isCorrect ? 'Correct' : 'Incorrect'}, XP earned: ${xpEarned}`);
  };

  const handleReset = (questionId: string) => {
    updateQuestionState(questionId, {
      userAnswer: '',
      selectedOption: undefined,
      isSubmitted: false,
      isCorrect: undefined,
      showExplanation: false,
    });
  };

  const handleLoadMore = () => {
    // Generate more mock questions for demo (todo: replace with real API call)
    const newQuestions = Array.from({ length: 4 }, (_, i) => 
      generateMockQuestion(
        `q-${currentYear}-${currentSubject}-${currentTopic}-${questions.length + i}`,
        currentYear,
        currentSubject,
        currentTopic,
        currentFormat
      )
    );
    setQuestions(prev => [...prev, ...newQuestions]);
    onLoadMore();
  };

  const totalQuestions = questions.length;
  const answeredQuestions = Array.from(questionStates.values()).filter(state => state.isSubmitted).length;
  const progressPercentage = totalQuestions > 0 ? (answeredQuestions / totalQuestions) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Progress Header */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">
                {currentSubject.charAt(0).toUpperCase() + currentSubject.slice(1)} - {currentTopic}
              </h2>
              <p className="text-sm text-muted-foreground">
                Year {currentYear} • {currentFormat.toUpperCase()} Format
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">
                {answeredQuestions}/{totalQuestions}
              </div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
          </div>
          <Progress value={progressPercentage} className="mt-4" data-testid="question-progress" />
        </CardHeader>
      </Card>

      {/* Questions */}
      <div className="space-y-4" data-testid="questions-container">
        {questions.map((question, index) => {
          const state = getQuestionState(question.id);
          const xpValue = currentYear * XP_MULTIPLIERS[currentFormat];
          
          return (
            <Card 
              key={question.id}
              className={`${state.isSubmitted ? (state.isCorrect ? 'border-green-200' : 'border-red-200') : ''}`}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-xs">
                    Question {index + 1}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {xpValue} XP
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="text-lg font-medium">{question.question}</div>
                
                {/* Answer Input Area */}
                {question.options ? (
                  // Multiple Choice Options
                  <div className="grid grid-cols-2 gap-3">
                    {question.options.map((option, optionIndex) => (
                      <Button
                        key={optionIndex}
                        variant={state.selectedOption === option ? "default" : "outline"}
                        className="h-auto p-4 text-left justify-start"
                        onClick={() => !state.isSubmitted && handleAnswerChange(question.id, option, true)}
                        disabled={state.isSubmitted}
                        data-testid={`option-${optionIndex}`}
                      >
                        <span className="font-medium mr-2">{String.fromCharCode(65 + optionIndex)}.</span>
                        {option}
                      </Button>
                    ))}
                  </div>
                ) : (
                  // Text Input
                  <Input
                    placeholder="Type your answer here..."
                    value={state.userAnswer}
                    onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                    disabled={state.isSubmitted}
                    className="text-lg"
                    data-testid="text-answer-input"
                  />
                )}

                {/* Action Buttons */}
                <div className="flex gap-2">
                  {!state.isSubmitted ? (
                    <Button
                      onClick={() => handleSubmit(question)}
                      disabled={!state.userAnswer && !state.selectedOption}
                      className="flex-1"
                      data-testid={`button-submit-${question.id}`}
                    >
                      Submit Answer
                    </Button>
                  ) : (
                    <div className="flex items-center gap-2 flex-1">
                      <div className={`flex items-center gap-2 ${state.isCorrect ? 'text-green-600' : 'text-red-600'}`}>
                        {state.isCorrect ? (
                          <CheckCircle className="h-5 w-5" />
                        ) : (
                          <XCircle className="h-5 w-5" />
                        )}
                        <span className="font-medium">
                          {state.isCorrect ? 'Correct!' : 'Incorrect'}
                        </span>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleReset(question.id)}
                        data-testid={`button-reset-${question.id}`}
                      >
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>

                {/* Explanation */}
                {state.showExplanation && question.explanation && (
                  <div className={`p-4 rounded-lg border-l-4 ${
                    state.isCorrect 
                      ? 'bg-green-50 border-green-400 text-green-800' 
                      : 'bg-blue-50 border-blue-400 text-blue-800'
                  }`}>
                    <div className="font-medium mb-1">Explanation:</div>
                    <div>{question.explanation}</div>
                    {!state.isCorrect && (
                      <div className="mt-2 text-sm">
                        <strong>Correct answer:</strong> {question.answer}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Load More Button */}
      <div className="flex justify-center">
        <Button
          variant="outline"
          onClick={handleLoadMore}
          disabled={loading}
          className="flex items-center gap-2"
          data-testid="button-load-more"
        >
          <ArrowDown className="h-4 w-4" />
          {loading ? 'Loading...' : 'Load More Questions'}
        </Button>
      </div>
    </div>
  );
}