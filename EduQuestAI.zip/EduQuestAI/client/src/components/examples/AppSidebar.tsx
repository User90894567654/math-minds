import { useState } from 'react';
import AppSidebar from '../AppSidebar';
import { SidebarProvider } from "@/components/ui/sidebar";
import { YearLevel, Subject, AnswerFormat } from '@shared/schema';

export default function AppSidebarExample() {
  const [currentYear, setCurrentYear] = useState<YearLevel>(7);
  const [currentSubject, setCurrentSubject] = useState<Subject>('math');
  const [currentTopic, setCurrentTopic] = useState('Linear Equations');
  const [currentFormat, setCurrentFormat] = useState<AnswerFormat>('text');

  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar
          currentYear={currentYear}
          currentSubject={currentSubject}
          currentTopic={currentTopic}
          currentFormat={currentFormat}
          onYearChange={setCurrentYear}
          onSubjectChange={setCurrentSubject}
          onTopicChange={setCurrentTopic}
          onFormatChange={setCurrentFormat}
        />
        <div className="flex-1 p-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Current Selection:</h3>
            <div className="space-y-2 text-sm">
              <p><strong>Year:</strong> {currentYear}</p>
              <p><strong>Subject:</strong> {currentSubject}</p>
              <p><strong>Topic:</strong> {currentTopic}</p>
              <p><strong>Format:</strong> {currentFormat}</p>
              <p><strong>XP Value:</strong> {currentYear * (currentFormat === 'mcq' ? 1 : currentFormat === 'text' ? 2 : 3)} XP</p>
            </div>
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
}