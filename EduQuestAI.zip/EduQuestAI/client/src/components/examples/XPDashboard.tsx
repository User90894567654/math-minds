import { useState } from 'react';
import XPDashboard from '../XPDashboard';
import { YearLevel, AnswerFormat } from '@shared/schema';

export default function XPDashboardExample() {
  const [totalXP, setTotalXP] = useState(850);
  const [currentLevel, setCurrentLevel] = useState(5);
  const [questionsAnswered, setQuestionsAnswered] = useState(47);
  const [correctAnswers, setCorrectAnswers] = useState(38);
  const [isBoostActive, setIsBoostActive] = useState(false);
  const [boostTimeLeft, setBoostTimeLeft] = useState(0);

  const currentYear: YearLevel = 9;
  const currentFormat: AnswerFormat = 'mixed';

  const handleBoostActivate = () => {
    console.log('Boost activated!');
    setIsBoostActive(true);
    setBoostTimeLeft(900); // 15 minutes
    
    // Simulate countdown
    const interval = setInterval(() => {
      setBoostTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsBoostActive(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">XP Dashboard Demo</h2>
        <p className="text-muted-foreground">
          Interactive demonstration of the XP and achievement system
        </p>
      </div>
      
      <XPDashboard
        totalXP={totalXP}
        currentLevel={currentLevel}
        questionsAnswered={questionsAnswered}
        correctAnswers={correctAnswers}
        currentYear={currentYear}
        currentFormat={currentFormat}
        onBoostActivate={handleBoostActivate}
        isBoostActive={isBoostActive}
        boostTimeLeft={boostTimeLeft}
      />
      
      <div className="bg-muted/30 p-4 rounded-lg">
        <h3 className="font-medium mb-2">Demo Controls</h3>
        <div className="grid grid-cols-2 gap-2">
          <button 
            className="px-3 py-2 bg-primary text-primary-foreground rounded text-sm"
            onClick={() => {
              setTotalXP(prev => prev + 27);
              setQuestionsAnswered(prev => prev + 1);
              setCorrectAnswers(prev => prev + 1);
            }}
          >
            Simulate Correct Answer (+27 XP)
          </button>
          <button 
            className="px-3 py-2 bg-secondary text-secondary-foreground rounded text-sm"
            onClick={() => {
              setQuestionsAnswered(prev => prev + 1);
            }}
          >
            Simulate Incorrect Answer
          </button>
        </div>
      </div>
    </div>
  );
}