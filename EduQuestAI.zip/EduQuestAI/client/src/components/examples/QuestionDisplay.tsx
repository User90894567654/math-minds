import { useState } from 'react';
import QuestionDisplay from '../QuestionDisplay';
import { YearLevel, Subject, AnswerFormat, Question } from '@shared/schema';

export default function QuestionDisplayExample() {
  const [totalXP, setTotalXP] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [loading, setLoading] = useState(false);

  const currentYear: YearLevel = 8;
  const currentSubject: Subject = 'math';
  const currentTopic = 'Linear Equations';
  const currentFormat: AnswerFormat = 'mixed';

  // Mock questions for demo
  const mockQuestions: Question[] = [
    {
      id: 'q1',
      yearLevel: currentYear,
      subject: currentSubject,
      topic: currentTopic,
      question: 'Solve for x: 3x + 7 = 22',
      answer: '5',
      questionType: 'text',
      explanation: 'Subtract 7 from both sides: 3x = 15. Then divide by 3: x = 5',
      difficulty: 1,
    },
    {
      id: 'q2',
      yearLevel: currentYear,
      subject: currentSubject,
      topic: currentTopic,
      question: 'What is the solution to 2x - 4 = 10?',
      answer: '7',
      options: ['5', '6', '7', '8'],
      questionType: 'mcq',
      explanation: 'Add 4 to both sides: 2x = 14. Then divide by 2: x = 7',
      difficulty: 1,
    },
    {
      id: 'q3',
      yearLevel: currentYear,
      subject: currentSubject,
      topic: currentTopic,
      question: 'If 4x + 3 = 2x + 11, find x',
      answer: '4',
      questionType: 'text',
      explanation: 'Subtract 2x from both sides: 2x + 3 = 11. Subtract 3: 2x = 8. Divide by 2: x = 4',
      difficulty: 1,
    },
  ];

  const handleAnswerSubmit = (questionId: string, answer: string, isCorrect: boolean, xpEarned: number) => {
    console.log(`Question ${questionId}: ${answer} - ${isCorrect ? 'Correct' : 'Incorrect'} (+${xpEarned} XP)`);
    setQuestionsAnswered(prev => prev + 1);
    if (isCorrect) {
      setCorrectAnswers(prev => prev + 1);
      setTotalXP(prev => prev + xpEarned);
    }
  };

  const handleLoadMore = () => {
    console.log('Loading more questions...');
    setLoading(true);
    setTimeout(() => setLoading(false), 1000);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Question Display Demo</h2>
        <p className="text-muted-foreground">
          Interactive math questions with XP system - Year {currentYear} {currentFormat} format
        </p>
      </div>

      {/* Demo Stats */}
      <div className="bg-muted/30 p-4 rounded-lg">
        <h3 className="font-medium mb-2">Session Stats</h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-primary">{totalXP}</div>
            <div className="text-sm text-muted-foreground">Total XP</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-green-600">
              {questionsAnswered > 0 ? Math.round((correctAnswers / questionsAnswered) * 100) : 0}%
            </div>
            <div className="text-sm text-muted-foreground">Accuracy</div>
          </div>
          <div>
            <div className="text-2xl font-bold">{questionsAnswered}</div>
            <div className="text-sm text-muted-foreground">Questions</div>
          </div>
        </div>
      </div>

      <QuestionDisplay
        questions={mockQuestions}
        currentYear={currentYear}
        currentSubject={currentSubject}
        currentTopic={currentTopic}
        currentFormat={currentFormat}
        onAnswerSubmit={handleAnswerSubmit}
        onLoadMore={handleLoadMore}
        loading={loading}
      />
    </div>
  );
}