import { useState, useEffect } from 'react';
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import AppSidebar from "@/components/AppSidebar";
import XPDashboard from "@/components/XPDashboard";
import QuestionDisplay from "@/components/QuestionDisplay";
import { Trophy, Menu, Sun, Moon } from 'lucide-react';
import { YearLevel, Subject, AnswerFormat, Question } from '@shared/schema';

export default function LearningApp() {
  // User state
  const [currentYear, setCurrentYear] = useState<YearLevel>(7);
  const [currentSubject, setCurrentSubject] = useState<Subject>('math');
  const [currentTopic, setCurrentTopic] = useState('Linear Equations');
  const [currentFormat, setCurrentFormat] = useState<AnswerFormat>('text');

  // Progress state
  const [totalXP, setTotalXP] = useState(0);
  const [currentLevel, setCurrentLevel] = useState(1);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);

  // UI state
  const [showXPDashboard, setShowXPDashboard] = useState(false);
  const [isBoostActive, setIsBoostActive] = useState(false);
  const [boostTimeLeft, setBoostTimeLeft] = useState(0);
  const [loading, setLoading] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Mock questions (todo: replace with real API)
  const [questions, setQuestions] = useState<Question[]>([]);

  // Update level based on XP
  useEffect(() => {
    const newLevel = Math.floor(totalXP / 100) + 1;
    if (newLevel > currentLevel) {
      setCurrentLevel(newLevel);
      // Level up celebration could go here
      console.log(`🎉 Level up! You reached level ${newLevel}!`);
    }
  }, [totalXP, currentLevel]);

  // Reset questions when selection changes
  useEffect(() => {
    setQuestions([]);
    setCurrentTopic(getDefaultTopic(currentSubject, currentYear));
  }, [currentYear, currentSubject, currentFormat]);

  // Dark mode toggle
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const getDefaultTopic = (subject: Subject, year: YearLevel): string => {
    const topics = {
      math: {
        7: 'Linear Equations',
        8: 'Quadratic Equations',
        9: 'Advanced Algebra',
      },
      science: {
        7: 'Biology Basics',
        8: 'Cell Biology',
        9: 'Evolution',
      },
      english: {
        7: 'Text Analysis',
        8: 'Poetry Analysis',
        9: 'Classic Literature',
      },
      history: {
        7: 'Ancient History',
        8: 'Industrial Age',
        9: 'World War I',
      },
    };
    
    return topics[subject]?.[year as keyof typeof topics[typeof subject]] || 'General Topics';
  };

  const handleAnswerSubmit = (questionId: string, answer: string, isCorrect: boolean, xpEarned: number) => {
    setQuestionsAnswered(prev => prev + 1);
    
    if (isCorrect) {
      setCorrectAnswers(prev => prev + 1);
      const finalXP = isBoostActive ? xpEarned * 2 : xpEarned;
      setTotalXP(prev => prev + finalXP);
      console.log(`✅ Correct! +${finalXP} XP ${isBoostActive ? '(2x Boost!)' : ''}`);
    } else {
      console.log(`❌ Incorrect answer for question ${questionId}`);
    }
  };

  const handleLoadMore = () => {
    setLoading(true);
    // Simulate loading delay
    setTimeout(() => setLoading(false), 500);
  };

  const handleBoostActivate = () => {
    if (!isBoostActive) {
      setIsBoostActive(true);
      setBoostTimeLeft(900); // 15 minutes
      
      const interval = setInterval(() => {
        setBoostTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            setIsBoostActive(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      console.log('🚀 XP Boost activated! 2x XP for 15 minutes!');
    }
  };

  const sidebarStyle = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full bg-background">
        <AppSidebar
          currentYear={currentYear}
          currentSubject={currentSubject}
          currentTopic={currentTopic}
          currentFormat={currentFormat}
          onYearChange={setCurrentYear}
          onSubjectChange={setCurrentSubject}
          onTopicChange={setCurrentTopic}
          onFormatChange={setCurrentFormat}
        />
        
        <div className="flex flex-col flex-1 min-w-0">
          {/* Header */}
          <header className="flex items-center justify-between p-4 border-b bg-card">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div className="flex items-center gap-2">
                <Trophy className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">XP Learning Academy</h1>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-sm">
                Level {currentLevel}
              </Badge>
              <Badge variant="outline" className="text-sm">
                {totalXP} XP
              </Badge>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowXPDashboard(!showXPDashboard)}
                className={showXPDashboard ? 'bg-primary text-primary-foreground' : ''}
                data-testid="button-toggle-xp"
              >
                <Trophy className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setIsDarkMode(!isDarkMode)}
                data-testid="button-theme-toggle"
              >
                {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-hidden">
            <div className="h-full flex">
              {/* Questions Area */}
              <div className="flex-1 p-6 overflow-y-auto">
                <QuestionDisplay
                  questions={questions}
                  currentYear={currentYear}
                  currentSubject={currentSubject}
                  currentTopic={currentTopic}
                  currentFormat={currentFormat}
                  onAnswerSubmit={handleAnswerSubmit}
                  onLoadMore={handleLoadMore}
                  loading={loading}
                />
              </div>

              {/* XP Dashboard Panel */}
              {showXPDashboard && (
                <div className="w-96 border-l bg-card p-6 overflow-y-auto">
                  <XPDashboard
                    totalXP={totalXP}
                    currentLevel={currentLevel}
                    questionsAnswered={questionsAnswered}
                    correctAnswers={correctAnswers}
                    currentYear={currentYear}
                    currentFormat={currentFormat}
                    onBoostActivate={handleBoostActivate}
                    isBoostActive={isBoostActive}
                    boostTimeLeft={boostTimeLeft}
                  />
                </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}