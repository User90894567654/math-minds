import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  yearLevel: integer("year_level").notNull(),
  subject: text("subject").notNull(),
  topic: text("topic").notNull(),
  totalXP: integer("total_xp").notNull().default(0),
  questionsAnswered: integer("questions_answered").notNull().default(0),
  correctAnswers: integer("correct_answers").notNull().default(0),
  currentLevel: integer("current_level").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const questions = pgTable("questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  yearLevel: integer("year_level").notNull(),
  subject: text("subject").notNull(),
  topic: text("topic").notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  options: jsonb("options"), // For MCQ questions
  difficulty: integer("difficulty").notNull().default(1),
  explanation: text("explanation"),
  questionType: text("question_type").notNull(), // 'mcq', 'text', 'mixed'
});

// Learning content structure
export type YearLevel = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
export type AnswerFormat = 'mcq' | 'text' | 'mixed';
export type Subject = 'math' | 'science' | 'english' | 'history';

export interface LearningProgress {
  yearLevel: YearLevel;
  subject: Subject;
  topic: string;
  totalXP: number;
  currentLevel: number;
  questionsAnswered: number;
  correctAnswers: number;
}

export interface Question {
  id: string;
  yearLevel: YearLevel;
  subject: Subject;
  topic: string;
  question: string;
  answer: string;
  options?: string[];
  questionType: AnswerFormat;
  explanation?: string;
  difficulty: number;
}

export interface XPCalculation {
  yearLevel: YearLevel;
  answerFormat: AnswerFormat;
  xpEarned: number; // yearLevel * multiplier (mcq=1, text=2, mixed=3)
}

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertProgressSchema>;
export type UserProgressData = typeof userProgress.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type QuestionData = typeof questions.$inferSelect;